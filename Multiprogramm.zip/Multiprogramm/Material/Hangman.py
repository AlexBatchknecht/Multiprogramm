import random

def display_hangman(tries):
    stages = [  # final state: head, torso, both arms, and both legs
                """
                   --------
                   |      |
                   |      O
                   |     \|/
                   |      |
                   |     / \\
                   -
                """,
                # head, torso, both arms, and one leg
                """
                   --------
                   |      |
                   |      O
                   |     \|/
                   |      |
                   |     / 
                   -
                """,
                # head, torso, and both arms
                """
                   --------
                   |      |
                   |      O
                   |     \|/
                   |      |
                   |      
                   -
                """,
                # head, torso, and one arm
                """
                   --------
                   |      |
                   |      O
                   |     \|
                   |      |
                   |     
                   -
                """,
                # head and torso
                """
                   --------
                   |      |
                   |      O
                   |      |
                   |      |
                   |     
                   -
                """,
                # head
                """
                   --------
                   |      |
                   |      O
                   |    
                   |      
                   |     
                   -
                """,
                # initial empty state
                """
                   --------
                   |      |
                   |      
                   |    
                   |      
                   |     
                   -
                """
    ]
    return stages[tries]

def get_word():
    word_list = ["python", "hangman", "grammatik", "cmd", "internet", "drucker"]
    word = random.choice(word_list)
    return word.upper()

word = []
word_completion = "_" * len(word)
guessed = False
guessed_letters = []
guessed_words = []
tries = 6

print("Willkommen beim Hangman-Spiel!")
print(display_hangman(tries))
print(word_completion)
print("\n")

while not guessed and tries > 0:
    guess = input("Bitte rate einen Buchstaben oder ein Wort: ").upper()
    if len(guess) == 1 and guess.isalpha():
        if guess in guessed_letters:
            print("Du hast diesen Buchstaben bereits geraten: ", guess)
        elif guess not in word:
            print(guess, "ist nicht in dem Wort enthalten.")
            tries -= 1
            guessed_letters.append(guess)
        else:
            print("Gut gemacht,", guess, "ist in dem Wort enthalten!")
            guessed_letters.append(guess)
            word_as_list = list(word_completion)
            indices = [i for i, letter in enumerate(word) if letter == guess]
            for index in indices:
                word_as_list[index] = guess
            word_completion = "".join(word_as_list)
            if "_" not in word_completion:
                guessed = True
    elif len(guess) == len(word) and guess.isalpha():
        if guess in guessed_words:
            print("Du hast dieses Wort bereits geraten: ", guess)
        elif guess != word:
            print(guess, "ist nicht das gesuchte Wort.")
            tries -= 1
            guessed_words.append(guess)
        else:
            guessed = True
            word_completion = word
    else:
        print("Ungültige Eingabe.")
    print(display_hangman(tries))
    print(word_completion)
    print("\n")

if word_completion == word:
    print("Herzlichen Glückwunsch, du hast das Wort geraten!")
    guessed = True
else:
    print("Leider hast du keine Versuche mehr. Das gesuchte Wort war " + word + ". Vielleicht beim nächsten Mal!")


