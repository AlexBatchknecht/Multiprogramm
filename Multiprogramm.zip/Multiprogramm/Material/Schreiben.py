import os
import random
import time

dir_path = f"C:\\Users\\{os.environ['USERNAME']}\\Desktop\\Multiprogramm\\Material"

def load_text(file_path):
    with open(file_path, "r", encoding="windows-1252") as f:
        return f.read()

def get_random_text(file_dir):
    valid_files = ["Text1.txt", "Test2.txt"]
    files = [f for f in os.listdir(file_dir) if f in valid_files]
    file_path = os.path.join(file_dir, random.choice(files))
    return load_text(file_path)

def run_test():
    print("Schreibe den folgenden Text so schnell wie möglich und ohne Fehler ab:\n")
    text = get_random_text(dir_path)
    print(text)
    
    input("Drücke Enter, um den Test zu starten.")
    start_time = time.time()
    user_input = input()
    end_time = time.time()

    errors = 0
    for i in range(min(len(user_input), len(text))):
        if user_input[i] != text[i]:
            errors += 1

    accuracy = 100 - (errors / len(text)) * 100
    time_taken = end_time - start_time
    typing_speed = len(user_input) / time_taken * 60

    print("\nErgebnis:")
    print(f"Zeit: {time_taken:.2f}s")
    print(f"Anzahl der Fehler: {errors}")
    print(f"Genauigkeit: {accuracy:.2f}%")
    print(f"Schreibgeschwindigkeit: {typing_speed:.2f} WPM")

    input("Drücke Enter, um das Programm zu beenden.")

if __name__ == "__main__":
    run_test()
